<nav class="navbar shadow navbar-expand-lg navbar-light" style="background-color:#ec7d33b2">
  <div class="container-fluid ">

    <a class="navbar-brand" href="index.php">
      <img src="image/Sawaripay.jpg" width="100" height="auto">
      <i>Safety rules are your best tools</i>
    </a>
    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container fluid" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link" aria-current="page" href="" style="font-size: 20px;">Home</a>
          <button type="button" class="btn btn-default" data-bs-toggle="modal" data-bs-target="#exampleModal"
            style="font-size: 20px;">About us
          </button>
          <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Sawaripay-Traffic Fine Management
                    System</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <p>
                  <h3 style="text-align: center"> <b>Sawaripay</b>
                    <h3>
                      <h5 style="text:align:center">Sawaripay helps you to take control of the
                        management of your fines.Resolving traffic fine issues can be
                        challenging and time-consuming.This system helps you to eases the
                        administrative burden of paying the fines of the citizens.Our fine
                        management system solution is user-friendly and cost-effective.<h5>
                          </p>
                </div>
                <div class="modal-footer">
                  <a class="btn btn-secondary" href="registration.php" role="button">Register</button></a>
                </div>
              </div>
            </div>
          </div>
          <button type="button" class="btn btn-default" data-bs-toggle="modal" data-bs-target="#amodal"
            style="font-size: 20px;">Contact Us

          </button>


          <div class="modal fade" id="amodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Contact Details</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <p>
                  <h3 style="text-align: center"> <b>Sawaripay</b>
                    <h3>
                      <h5 style="text:align:center">Contact us on:<h5>
                          </p>
                          <h5 style="text:align:center">9814796247<h5>
                              </p>
                              <h5 style="text:align:center">9861623154<h5>
                                  </p>
                                  <h5 style="text:align:center">Thank you<h5>
                                      </p>
                </div>
                <div class="modal-footer">
                  <a class="btn btn-secondary" href="registration.php" role="button">Register</button></a>

                </div>
              </div>
            </div>
          </div>
          <a href="registration.php">
            <button type="button" class="btn btn-secondary" style="line-height: 1.5;">Register</button>
          </a>
          <span style="margin-right: 10px;"></span>
          <a href="login.php">
            <button type="button" class="btn btn-primary" style="line-height: 1.5;">Login</button>
          </a>
        </div>
    </nav>
  </div>
  </div>
</nav>