<!--Side bar-->
<div class="col-3 border-end p-4">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" aria-current="page" href="dashboard.php">
                <i class="fa-solid fa-house"></i>Home</a>
        </li>


        <li class="nav-item">
            <a class="nav-link" aria-current="page" href="user.php">
                <i class="fa-solid fa-user-group"></i>User Details</a>
        </li>

        <li class="nav-item">
            <a class="nav-link" aria-current="page" href="fine.php">
                <i class="fa-solid fa-credit-card"></i>Offence List</a>
        </li>

        <li class="nav-item">
            <a class="nav-link" aria-current="page" href="repeat_offenders.php">
                <i class="fa-solid fa-credit-card"></i>Repeat Offenders</a>
        </li>

    </ul>
</div>



<!---Side bar end-->