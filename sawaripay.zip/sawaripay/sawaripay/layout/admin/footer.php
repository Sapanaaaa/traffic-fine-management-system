<!--Content Footer start--->
<div class="container-fluid bg-dark">
<ul class="nav nav-pills nav-fill">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#"></a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#"></a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#"></a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled"></a>
  </li>
</ul>
</div>
    <!--Content Footer end--->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="fontawesome/js/all.css"></script>
</body>
</html>