<!--Side bar-->
<div class="col-3 border-end p-4">
  <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link" aria-current="page" href="userdashboard.php">
      <i class="fa-solid fa-house"></i>Home</a>
    </li>


    <li class="nav-item">
      <a class="nav-link " aria-current="page" href="profile.php">
      <i class="fa-solid fa-user-group"></i>Profile</a>
    </li>


    <li class="nav-item">
      <a class="nav-link" aria-current="page" href="finelist.php">Fine List</a>
    </li>

    
  </ul>
</div>



     <!---Side bar end-->